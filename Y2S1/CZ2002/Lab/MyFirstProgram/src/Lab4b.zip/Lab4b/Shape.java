package Lab4b;

public interface Shape {
    public double getArea();
    public String getShape();
}
